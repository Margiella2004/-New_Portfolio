
  # Make Code Live

  This is a code bundle for Make Code Live. The original project is available at https://www.figma.com/design/Pwy409OP631K132IJgS3hE/Make-Code-Live.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  