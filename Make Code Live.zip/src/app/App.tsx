import React from "react";
import svgPaths from "../imports/svg-yta2irbm7o";
import imgLetsgo1 from "figma:asset/908f4e055ae7cfb763b16481a379de836899ad63.png";
import imgScreenshot20251212At101636Pm1 from "figma:asset/13c23ad96d40c8ab565439ab313623391a80f732.png";

export default function App() {
  return (
    <div className="relative min-h-screen w-full bg-black font-sans text-white overflow-hidden" style={{ fontFamily: '"Inter", sans-serif' }}>
      {/* Background Image */}
      <div className="absolute inset-0 z-0">
        <img
          src={imgScreenshot20251212At101636Pm1}
          alt="Background"
          className="w-full h-full object-cover opacity-80"
        />
        {/* Overlay gradient to ensure text readability if needed, though the image seems dark enough/colored enough */}
        <div className="absolute inset-0 bg-black/10 mix-blend-overlay" />
      </div>

      {/* Main Content Container */}
      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-[1216px] flex-col justify-center px-6 py-10 md:py-16 lg:px-0 lg:py-20">
        {/* Top Horizontal Line */}
        <div className="mb-8 h-px w-full bg-white/50 lg:mb-12" />

        {/* Hero Section */}
        <div className="flex flex-col-reverse gap-8 md:gap-10 lg:flex-row lg:items-start lg:justify-between lg:gap-[19px]">
          {/* Left Text */}
          <div className="flex max-w-2xl flex-col">
            <h1 className="text-[30px] font-normal leading-[36px] tracking-[-0.9px]">
              Jonathan Ramesh is a Interdisciplinary Designer focusing on UX
              Design and Engineering. Jonathan combines his coding experince and
              design education to create products focused on bringing back human
              centered design
            </h1>
          </div>

          {/* Right Image */}
          <div className="relative h-[300px] w-full shrink-0 overflow-hidden rounded-sm md:h-[340px] lg:h-[377px] lg:w-[305px]">
            <img
              src={imgLetsgo1}
              alt="Jonathan Ramesh"
              className="absolute left-[-7%] top-0 h-full max-w-[125%] object-cover grayscale"
            />
          </div>
        </div>

        {/* Spacer */}
        <div className="h-16 md:h-24 lg:h-32" />

        {/* Footer / Details Section */}
        <div className="flex flex-col gap-12 md:flex-row md:items-end md:justify-between lg:gap-16">
          {/* Lists Container */}
          <div className="flex flex-col gap-10 sm:flex-row sm:gap-24 lg:gap-[250px]">
            {/* Companies */}
            <div className="flex flex-col items-start">
              <h3 className="text-[20.093px] leading-[29.69px] tracking-[-0.6028px] italic text-[rgba(252,252,252,0.81)]" style={{ fontFamily: '"Instrument Serif", serif' }}>
                Companies
              </h3>
              <div className="flex flex-col text-[14px] leading-[29.69px] tracking-[-0.42px] font-normal text-[#fcfcfc]">
                <p>Sensigo (Oct 2025 - Present)</p>
                <p>Synechron (May 2024-2025)</p>
                <p>MedRcm (May 2022- Jun 2022)</p>
              </div>
            </div>

            {/* Certifications */}
            <div className="flex flex-col items-start">
              <h3 className="text-[20.093px] leading-[29.69px] tracking-[-0.6028px] italic text-[rgba(252,252,252,0.81)]" style={{ fontFamily: '"Instrument Serif", serif' }}>
                Certifications
              </h3>
              <div className="flex flex-col text-[14px] leading-[29.69px] tracking-[-0.42px] font-normal text-[#fcfcfc]">
                <p>AI For UX Research</p>
                <p>Three.js Journey</p>
                <p>Introduction to Web Accesibility</p>
              </div>
            </div>
          </div>

          {/* CTA */}
          <div className="flex items-center gap-3 pb-2 pt-8 md:pt-0">
            <span className="text-[30px] leading-[36px] tracking-[-0.9px] font-normal">
              lets get working
            </span>
            <div className="relative size-[38px]">
              <svg
                viewBox="0 0 38 38"
                fill="none"
                className="size-full"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d={svgPaths.p18087100}
                  fill="currentColor"
                  className="text-white"
                />
              </svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
