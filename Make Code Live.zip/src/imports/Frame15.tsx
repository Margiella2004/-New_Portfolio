import svgPaths from "./svg-yta2irbm7o";
import imgLetsgo1 from "figma:asset/908f4e055ae7cfb763b16481a379de836899ad63.png";
import imgScreenshot20251212At101636Pm1 from "figma:asset/13c23ad96d40c8ab565439ab313623391a80f732.png";

function Frame2() {
  return <div className="h-[32px] shrink-0 w-[307.652px]" />;
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-col gap-[14px] items-start relative shrink-0">
      <p className="font-['Pangea_Afrikan_VAR_2.003:Regular',sans-serif] font-normal leading-[36px] relative shrink-0 text-[30px] text-white tracking-[-0.9px] w-[572.646px]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>{`Jonathan Ramesh is a Interdisciplinary Designer focusing on UX Design and Engineering. Jonathan combines his coding experince and design education to create products focused on  bringing back human centered design`}</p>
      <Frame2 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-stretch flex items-start justify-between relative shrink-0 w-full">
      <Frame3 />
      <div className="h-[377px] relative shrink-0 w-[304.878px]" data-name="letsgo 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-7.26%] max-w-none top-0 w-[123.66%]" src={imgLetsgo1} />
        </div>
      </div>
    </div>
  );
}

function IntroText() {
  return (
    <div className="content-stretch flex flex-col gap-[19px] items-start relative shrink-0 w-[1216px]" data-name="intro text">
      <div className="h-0 relative shrink-0 w-[1216px]">
        <div className="absolute inset-[-0.5px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1216 1">
            <line id="Line 1" stroke="var(--stroke-0, white)" strokeWidth="0.5" x2="1216" y1="0.25" y2="0.25" />
          </svg>
        </div>
      </div>
      <Frame1 />
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-stretch flex flex-col font-['Pangea_Afrikan_VAR_2.003:Regular',sans-serif] font-normal items-start leading-[29.69px] pb-[5px] pt-0 px-0 relative shrink-0 text-[#fcfcfc] text-[14px] tracking-[-0.42px] w-full">
      <p className="min-w-full relative shrink-0 w-[min-content]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        Sensigo (Oct 2025 - Present)
      </p>
      <p className="min-w-full relative shrink-0 w-[min-content]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        Synechron (May 2024-2025)
      </p>
      <p className="relative shrink-0 w-[195px]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        MedRcm (May 2022- Jun 2022)
      </p>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[160px]">
      <p className="font-['Instrument_Serif:Italic',sans-serif] italic leading-[29.69px] relative shrink-0 text-[20.093px] text-[rgba(252,252,252,0.81)] tracking-[-0.6028px] w-full">Companies</p>
      <Frame6 />
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-stretch flex flex-col font-['Pangea_Afrikan_VAR_2.003:Regular',sans-serif] font-normal items-start leading-[29.69px] pb-[5px] pt-0 px-0 relative shrink-0 text-[#fcfcfc] text-[14px] tracking-[-0.42px] w-full">
      <p className="min-w-full relative shrink-0 w-[min-content]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        AI For UX Research
      </p>
      <p className="min-w-full relative shrink-0 w-[min-content]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        Three.js Journey
      </p>
      <p className="relative shrink-0 w-[195px]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        Introduction to Web Accesibility
      </p>
    </div>
  );
}

function Frame8() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-[160px]">
      <p className="font-['Instrument_Serif:Italic',sans-serif] italic leading-[29.69px] relative shrink-0 text-[20.093px] text-[rgba(252,252,252,0.81)] tracking-[-0.6028px] w-full">Certifications</p>
      <Frame7 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex gap-[251px] items-center relative shrink-0">
      <Frame9 />
      <Frame8 />
    </div>
  );
}

function Frame5() {
  return (
    <div className="h-[36px] relative shrink-0 w-[38px]">
      <div className="absolute inset-[0_0_-3.36%_0]">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 38 38">
          <g id="Frame 40">
            <path d={svgPaths.p18087100} fill="var(--stroke-0, white)" id="Vector 1" />
          </g>
        </svg>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-stretch flex gap-[11px] items-end relative shrink-0">
      <p className="font-['Pangea_Afrikan_VAR_2.003:Regular',sans-serif] font-normal leading-[36px] relative shrink-0 text-[30px] text-white tracking-[-0.9px] w-[194px]" style={{ fontVariationSettings: "'ital' 0, 'XTDR' 0, 'APRT' 0, 'SPAC' 0, 'INKT' 0, 'SS01' 0, 'SS02' 0, 'SS03' 0" }}>
        lets get working
      </p>
      <Frame5 />
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex items-end justify-between relative shrink-0 w-full">
      <Frame10 />
      <Frame4 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="absolute content-stretch flex flex-col gap-[129px] items-center left-[63px] top-[161px] w-[1227px]">
      <IntroText />
      <Frame11 />
    </div>
  );
}

export default function Frame() {
  return (
    <div className="relative size-full">
      <div className="absolute h-[830px] left-[-15px] top-0 w-[1371px]" data-name="Screenshot 2025-12-12 at 10.16.36 PM 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-full left-[-6.42%] max-w-none top-0 w-[112.33%]" src={imgScreenshot20251212At101636Pm1} />
        </div>
      </div>
      <Frame12 />
    </div>
  );
}